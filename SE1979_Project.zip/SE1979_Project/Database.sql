﻿-- 1. Bảng Role
CREATE TABLE Role (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description VARCHAR(255)
);

INSERT INTO Role (name, description) VALUES
('Admin', 'Administrator with full permissions'),
('Customer', 'Regular customer');

-- 2. Bảng Status
CREATE TABLE Status (
    statusId INT IDENTITY(1,1) PRIMARY KEY,
    status VARCHAR(50) NOT NULL
);

INSERT INTO Status (status) VALUES
('Active'),
('Inactive'),
('Pending'),
('Delivered'),
('Cancelled');

-- 3. Bảng User
CREATE TABLE [User] (
    id INT IDENTITY(1,1) PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    address VARCHAR(255),
    phone VARCHAR(20),
    avatar VARCHAR(255),
    roleId INT,
    FOREIGN KEY (roleId) REFERENCES Role(id)
);

INSERT INTO [User] (email, password, firstName, lastName, address, phone, avatar, roleId) VALUES
('admin@example.com', 'admin123', 'Admin', 'User', '123 Admin St', '0123456789', 'avatar1.png', 1),
('john.doe@example.com', 'john123', 'John', 'Doe', '456 Elm St', '0987654321', 'avatar2.png', 2),
('jane.smith@example.com', 'jane123', 'Jane', 'Smith', '789 Oak St', '0112233445', 'avatar3.png', 2);

-- 4. Bảng Dish (có quantity)
CREATE TABLE Dish (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    description VARCHAR(MAX),
    image VARCHAR(255),
	category VARCHAR(100),
    quantity INT DEFAULT 0,
);

-- BURGER (4 items)
INSERT INTO Dish (name, price, description, image, quantity, category) VALUES
('Classic Beef Burger', 85000.00, 'A classic featuring a juicy beef patty, our signature sauce on a soft, toasted bun.', 'burger.jpg', 100, 'burger'),
('Special Crispy Chicken Burger', 95000.00, 'Experience the crunch of crispy fried chicken, melted cheese, a spicy mayo kick.', 'f7.png', 100, 'burger'),
('Grilled Chicken Sandwich', 75000.00, 'A healthy choice with tender grilled chicken, served on wholesome whole-wheat bread.', 'f8.png', 100, 'burger'),
('Giant Double Patty Burger', 120000.00, 'A towering feast! Stacked high with fresh toppings for the ultimate indulgence.', 'burger4.png', 100, 'burger'),
('Spicy Black Bean Veggie Burger', 70000.00, 'A Plant-based black beans, topped with avocado and fresh salsa on a soft bun.', 'f2.png', 100, 'burger');

-- PIZZA (6 items)
INSERT INTO Dish (name, price, description, image, quantity, category) VALUES
('Traditional Margarita Pizza', 140000.00, 'San Marzano tomato sauce, mozzarella, baked on our perfectly crisp thin crust.', 'pizza.jpg', 100, 'pizza'),
('Premium Seafood Pizza', 165000.00, 'A rich ocean of succulent shrimp, creamy garlic sauce over a delicious thin base.', 'f1.png', 100, 'pizza'),
('Classic Pepperoni Pizza', 150000.00, 'Generous spicy pepperoni , mozzarella cheese baked to a perfect golden brown.', 'f3.png', 100, 'pizza'),
('Feane''s Signature 6-Flavor Pizza', 185000.00, 'Explore six distinct, rich flavors breast, offering taste journey for every palate.', 'f6.png', 100, 'pizza'),
('Baked Bolognese Beef Pizza', 110000.00, 'Hearty Bolognese meat sauce and melted cheese, offering a comforting Italian twist.', 'pizza1.jpg', 100, 'pizza'),
('BBQ Pork and Pineapple Pizza', 145000.00, 'A surprising mix of BBQ pulled pork,a tangy barbecue base for a tropical bite.', 'pizza2.jpg', 100, 'pizza');

-- PASTA (3 items)
INSERT INTO Dish (name, price, description, image, quantity, category) VALUES
('Truffle Mushroom Pasta', 95000.00, 'Luxurious pasta tossed in a velvety cream sauce, and finished with shaved Parmesan.', 'f4.png', 100, 'pasta'),
('Baked Cheese Macaroni', 105000.00, 'Comfort food at its best: macaroni coated in a rich, topped with a golden crust.', 'f9.png', 100, 'pasta'),
('Chilled Pasta Salad', 60000.00, 'A refreshing medley of perfectly cooked spiral pasta, tossed in a light vinaigrette.', 'pasta.png', 100, 'pasta'),
('Classic Spaghetti Carbonara', 115000.00, 'Authentic Roman pasta featuring dente spaghetti, with fresh Pecorino cheese.', 'pasta1.png', 100, 'pasta'),
('Sun-Dried Tomato Pesto', 90000.00, 'Al dente pasta tossed in vibrant sun-dried, a touch of olive oil, summery taste.', 'pasta2.png', 100, 'pasta');

-- FRIES (3 items)
INSERT INTO Dish (name, price, description, image, quantity, category) VALUES
('Thick-Cut Crispy Fries', 40000.00, 'Extra crispy thick-cut potato fries. A classic side for any meal, served piping hot.', 'f5.png', 100, 'fries'),
('Sweet Potato Fries', 50000.00, 'Naturally sweet and crispy fries, served with our signature sauce for a balanced flavor.', 'fries2.png', 100, 'fries'),
('Truffle Parmesan Fries', 65000.00, 'Gourmet fries tossed in aromatic truffle oil and Parmesan cheese for an intense flavor.', 'fries1.png', 100, 'fries');

-- 5. Bảng CartItem
CREATE TABLE CartItem (
    cartItemId INT IDENTITY(1,1) PRIMARY KEY,
    userId INT NOT NULL,
    dishId INT NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (userId) REFERENCES [User](id),
    FOREIGN KEY (dishId) REFERENCES Dish(id)
);

INSERT INTO CartItem (userId, dishId, quantity) VALUES
(2, 1, 2),
(2, 2, 1),
(3, 3, 3);

-- 6. Bảng Order
CREATE TABLE [Order] (
    orderId INT IDENTITY(1,1) PRIMARY KEY,
    userId INT NOT NULL,
    date DATETIME DEFAULT GETDATE() NOT NULL,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255),
    shipPrice DECIMAL(10,2) DEFAULT 0,
    totalPrice DECIMAL(10,2) NOT NULL,
    statusId INT,
    note VARCHAR(MAX),
    FOREIGN KEY (userId) REFERENCES [User](id),
    FOREIGN KEY (statusId) REFERENCES Status(statusId)
);

INSERT INTO [Order] (userId, name, phone, address, shipPrice, totalPrice, statusId, note) VALUES
(2, 'John Doe', '0987654321', '456 Elm St', 20000.00, 300000.00, 3, 'Please deliver quickly'),
(3, 'Jane Smith', '0112233445', '789 Oak St', 30000.00, 450000.00, 3, 'No onions please');

-- 7. Bảng OrderDetail
CREATE TABLE OrderDetail (
    orderDetailId INT IDENTITY(1,1) PRIMARY KEY,
    orderId INT NOT NULL,
    dishId INT NOT NULL,
    quantity INT NOT NULL,
    priceDish DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (orderId) REFERENCES [Order](orderId),
    FOREIGN KEY (dishId) REFERENCES Dish(id)
);

INSERT INTO OrderDetail (orderId, dishId, quantity, priceDish) VALUES
(1, 1, 2, 85000.00),
(1, 2, 1, 140000.00),
(2, 3, 3, 60000.00);
